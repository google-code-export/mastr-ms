"""
FilterSpec encapsulates the logic for displaying filters in the Django admin.
Filters are specified in models with the "list_filter" option.

Each filter subclass knows how to display a filter for a field that passes a
certain test -- e.g. being a DateField or ForeignKey.
"""

from django.db import models
from django.utils.encoding import smart_unicode, iri_to_uri
from django.utils.translation import ugettext as _
from django.utils.html import escape
from django.utils.safestring import mark_safe
import datetime

class FilterSpec(object):
	HAS_OWN_OUTPUT = False						# set to true in a subclass if you want the filter to run the objects output() method rather than choices()
	
	filter_specs = []
	def __init__(self, f, request, params, model, model_admin):
		self.field = f
		self.params = params
		
		self.displaymulti = False
		self.multiselect=False
		self.multitag=''

	def register(cls, test, factory):
		cls.filter_specs.append((test, factory))
	register = classmethod(register)

	def create(cls, f, request, params, model, model_admin):
		#assert False
		for test, factory in cls.filter_specs:
			if test(f):
				return factory(f, request, params, model, model_admin)
	create = classmethod(create)

	def has_output(self):
		return True

	def choices(self, cl):
		raise NotImplementedError()

	def title(self):
		return self.field.verbose_name

class obj:
	def __init__(self, name):
            self.pk = name
            
        def __str__(self):
            return self.pk

class DistantFieldFilterSpec(FilterSpec):
	def __init__(self, filter_term, request, params, model, model_admin):
		super(DistantFieldFilterSpec, self).__init__(None, request, params, model, model_admin)
		
		self.displaymulti=True
		
		assert '__' in filter_term
		
		filter_parts=filter_term.split("__")
		
		# Go through the filter parts (seperated by __) and traverse the model structure to find the final model to do a lookup on.
		mod = model
		self.endfield = None			# does it end with a non joining field.
		for part in filter_parts:
			#print "PART",part
			fld = mod._meta.get_field_by_name(part)[0]
			if fld.rel:
				mod = fld.rel.to
			else:
				self.endfield = part
				
		#print "ENDFIELD",self.endfield
		getkeys = request.GET.keys()
		
		# if our filter term passed in ends in "exact"
		exact=True
		for term in getkeys:
			if term.startswith(filter_term):
				#this may be the filter we are interested in
				extension = term[len(filter_term):]
				if extension=="__in":
					exact = False
				
		#print "EXACT",exact
			
		self.lookup_title = mod._meta.verbose_name
		
		if exact:
			self.lookup_kwarg = '%s__exact' % filter_term
			#self.multitag = '%s__in' % filter_term + "="+str(request.GET.get(self.lookup_kwarg, None))
			self.multitag = request.META['QUERY_STRING'].replace(self.lookup_kwarg,self.lookup_kwarg.replace('__exact','__in'))
			self.multiselect = False
		else:
			self.lookup_kwarg = '%s__in' % filter_term
			self.multiselect = True
			
			# the multi link tag here has to be the full hyperlink, but with the present filters condition removed.
			outterms=[]
			for term in getkeys:
				if term.startswith(filter_term):
					#this may be the filter we are interested in
					extension = term[len(filter_term):]
					if extension!="__in":
						#this is not us. We should add it so we remember it
						outterms.append(term)
				else:
					outterms.append(term)
			self.multitag = "&".join([term+"="+request.GET[term] for term in outterms])
			
		self.lookup_val = request.GET.get(self.lookup_kwarg, None)
		
		if self.endfield==None:
			self.lookup_choices = mod.objects.all()
		else:
			# lets isolate the unique set of that field
			query = mod.objects.all()
			names=set([getattr(q,self.endfield) for q in query])
			self.lookup_choices = []
			for name in names:
				self.lookup_choices.append( obj(name) )
			
		
		# if this is None then "All" is selected. This means our "multi" link must switch EVERY filter option on.
		if self.lookup_val is None:
			# construct the 'in' list
			inlist = [a.pk for a in self.lookup_choices]
			self.multitag = "&".join([term+"="+request.GET[term] for term in getkeys])+"&"+self.lookup_kwarg.replace("__exact","__in")+"="+",".join([str(x) for x in inlist])
			
		#print self.lookup_kwarg,",",self.lookup_val,",",self.lookup_choices

	def has_output(self):
		return len(self.lookup_choices) > 1

	def title(self):
		return self.lookup_title

	def choices(self, cl):
		if not self.multiselect:
			yield {'selected': self.lookup_val is None,
				'query_string': cl.get_query_string({}, [self.lookup_kwarg]),
				'display': _('All')}
		
		lookupvals = []
		if self.multiselect and self.lookup_val != None:
			lookupvals = [smart_unicode(x) for x in self.lookup_val.split(",")]
			
		#print "LV:",lookupvals,"choices:",self.lookup_choices
			
		for val in sorted(self.lookup_choices,key=lambda x: str(x)):
			pk_val = self.lookup_val
			selected = False
			
			if self.multiselect:
				selected = smart_unicode(val.pk) in lookupvals
			else:
				selected = self.lookup_val == smart_unicode(val.pk)
			#print selected,smart_unicode(val.pk),lookupvals,self.lookup_kwarg,pk_val
			if self.endfield==None:
				v = val
			else:
				v= val.pk
			query=cl.get_query_string({self.lookup_kwarg: pk_val})
			#print query
			if pk_val!=None:
				if not selected:
					#print "A"
					if self.multiselect:
						query=cl.get_query_string({self.lookup_kwarg: smart_unicode(pk_val+u","+smart_unicode(val.pk))})
					else:
						query=cl.get_query_string({self.lookup_kwarg: smart_unicode(smart_unicode(val.pk))})
				else:
					#print "B"
					if self.multiselect:
						query=cl.get_query_string({self.lookup_kwarg: smart_unicode(",".join([x for x in pk_val.split(",") if x!=unicode(val.pk)]))})
					else:
						query=cl.get_query_string({self.lookup_kwarg: smart_unicode(smart_unicode(val.pk))})
			else:
				#print "C"
				query=cl.get_query_string({self.lookup_kwarg: str(val.pk)})
			
			yield {'selected': selected,
					'query_string': query,
					'display': v,
					}
			
				
#FilterSpec.register(lambda f: f==None, DistantFieldFilterSpec)

class FieldFilterSpec(FilterSpec):
	pass

class RangeFilterSpec(FieldFilterSpec):
	HAS_OWN_OUTPUT = True
	
	def __init__(self, filter_term,f, request, params, model, model_admin, prefix=""):
		super(RangeFilterSpec, self).__init__(f, request, params, model, model_admin)
		#print f, params, model, model_admin
		
		#assert isinstance(f, models.IntegerField) or isinstance(f, models.FloatField)
		self.lookup_title = f.verbose_name

		self.form_name = "range_%s"%f.name
		self.from_key = prefix+f.name+"__gte"
		self.to_key = prefix+f.name+"__lte"
		
		self.range_active = self.from_key in request.GET
		
		#print model.objects.all()
		self.min_value = request.GET[self.from_key] if self.range_active else ""
		self.max_value = request.GET[self.to_key] if self.range_active else ""
		
		self.querycopy=request.GET.copy()
		if self.range_active:
			#calculate the get line without these tags
			if self.from_key in self.querycopy:
				del self.querycopy[self.from_key]
			if self.to_key in self.querycopy:
				del self.querycopy[self.to_key]
			
		

	def has_output(self):
		return True

	def title(self):
		return "%s range"%self.lookup_title

	def choices(self, cl):
		raise NotImplementedError()
	
	def output(self, cl):
		t = []
		if self.has_output():
			t.append(_(u'<h3>By %s:</h3>\n') % escape(self.title()))
			t.append("<ul>\n")
			t.append(_(u'<li%s><a href=".?%s">All</a></li>\n'%(' class="selected"' if not self.range_active else '',self.querycopy.urlencode())))
			t.append(_(u'<li%s><form method="GET" action="." name="%s">%s<input name="%s" value="%s" size="3"/> - <input name="%s" value="%s" size="3"/>&nbsp;&nbsp;&nbsp;<a href="#" onClick="%s.submit();">Go</a></form></li>\n'%(' class="selected"' if self.range_active else '',self.form_name, cl.build_hidden_input_tags(), self.from_key, self.min_value, self.to_key, self.max_value, self.form_name)))
			t.append("</ul>\n")
		return mark_safe("".join(t))


class RelatedFilterSpec(FieldFilterSpec):
	def __init__(self, filter_term,f, request, params, model, model_admin):
		super(RelatedFilterSpec, self).__init__(f, request, params, model, model_admin)
		if isinstance(f, models.ManyToManyField):
			self.lookup_title = f.rel.to._meta.verbose_name
		else:
			self.lookup_title = f.verbose_name
		self.lookup_kwarg = '%s__%s__exact' % (f.name, f.rel.to._meta.pk.name)
		self.lookup_val = request.GET.get(self.lookup_kwarg, None)
		
		self.displaymulti = True
		self.multiselect=False
		self.multitag=''
		
		self.lookup_choices = f.rel.to._default_manager.all()
		
		getkeys = request.GET.keys()
		
		# if our filter term passed in ends in "exact"
		exact=True
		for term in getkeys:
			if term.startswith(filter_term):
				#this may be the filter we are interested in
				extension = term[len(filter_term):]
				#print extension
				if extension=="__in" or extension=="__id__in":
					exact = False
				
		#print "EXACT",exact
			
		if exact:
			self.lookup_kwarg = '%s__%s__exact' % (f.name, f.rel.to._meta.pk.name)
			#self.multitag = '%s__in' % filter_term + "="+str(request.GET.get(self.lookup_kwarg, None))
			self.multitag = request.META['QUERY_STRING'].replace(self.lookup_kwarg,self.lookup_kwarg.replace('__exact','__in'))
			self.multiselect = False
		else:
			self.lookup_kwarg = '%s__%s__in' % (f.name, f.rel.to._meta.pk.name)
			self.lookup_val = [int(x) for x in request.GET.get(self.lookup_kwarg, None).split(",")]
			self.multiselect = True
			
			# the multi link tag here has to be the full hyperlink, but with the present filters condition removed.
			outterms=[]
			#print "KEYS",getkeys
			for term in getkeys:
				if term.startswith(filter_term):
					#this may be the filter we are interested in
					extension = term[len(filter_term):]
					#print extension
					if extension!="__in" and extension!="__id__in":
						#this is not us. We should add it so we remember it
						outterms.append(term)
				else:
					outterms.append(term)
			self.multitag = "&".join([term+"="+request.GET[term] for term in outterms])
			
		# if this is None then "All" is selected. This means our "multi" link must switch EVERY filter option on.
		if self.lookup_val is None:
			# construct the 'in' list
			inlist = [a.pk for a in self.lookup_choices]
			self.multitag = "&".join([term+"="+request.GET[term] for term in getkeys])+"&"+self.lookup_kwarg.replace("__exact","__in")+"="+",".join([str(x) for x in inlist])

	def has_output(self):
		return len(self.lookup_choices) > 1

	def title(self):
		return self.lookup_title

	def choices(self, cl):
		if not self.multiselect:
			yield {'selected': self.lookup_val is None,
				'query_string': cl.get_query_string({}, [self.lookup_kwarg]),
				'display': _('All')}
		for val in sorted(self.lookup_choices, key=lambda x: str(x)):
                        pk_val = getattr(val, self.field.rel.to._meta.pk.attname)
			#print pk_val,self.lookup_val,self.lookup_kwarg,val
			
			if self.multiselect:
				selected=pk_val in self.lookup_val
				if selected:
					yield {'selected': selected,
						'query_string': cl.get_query_string({self.lookup_kwarg: u",".join([smart_unicode(v) for v in self.lookup_val if v!=pk_val])}),
						'display': val}
				else:
					yield {'selected': selected,
						'query_string': cl.get_query_string({self.lookup_kwarg: u",".join([smart_unicode(v) for v in self.lookup_val+[pk_val]])}),
						'display': val}
				
			else:
				yield {'selected': self.lookup_val == smart_unicode(pk_val),
					'query_string': cl.get_query_string({self.lookup_kwarg: pk_val}),
					'display': val}
				
FilterSpec.register(lambda f: bool(f.rel), RelatedFilterSpec)

class ChoicesFilterSpec(FieldFilterSpec):
	def __init__(self, f, request, params, model, model_admin):
		super(ChoicesFilterSpec, self).__init__(f, request, params, model, model_admin)
		self.lookup_kwarg = '%s__exact' % f.name
		self.lookup_val = request.GET.get(self.lookup_kwarg, None)

	def choices(self, cl):
		yield {'selected': self.lookup_val is None,
			'query_string': cl.get_query_string({}, [self.lookup_kwarg]),
			'display': _('All')}
		for k, v in self.field.choices:
			yield {'selected': smart_unicode(k) == self.lookup_val,
					'query_string': cl.get_query_string({self.lookup_kwarg: k}),
					'display': v}

FilterSpec.register(lambda f: bool(f.choices), ChoicesFilterSpec)

class DateFieldFilterSpec(FieldFilterSpec):
	def __init__(self, f, request, params, model, model_admin):
		super(DateFieldFilterSpec, self).__init__(f, request, params, model, model_admin)

		self.field_generic = '%s__' % self.field.name

		self.date_params = dict([(k, v) for k, v in params.items() if k.startswith(self.field_generic)])

		today = datetime.date.today()
		one_week_ago = today - datetime.timedelta(days=7)
		today_str = isinstance(self.field, models.DateTimeField) and today.strftime('%Y-%m-%d 23:59:59') or today.strftime('%Y-%m-%d')

		self.links = (
			(_('Any date'), {}),
			(_('Today'), {'%s__year' % self.field.name: str(today.year),
					'%s__month' % self.field.name: str(today.month),
					'%s__day' % self.field.name: str(today.day)}),
			(_('Past 7 days'), {'%s__gte' % self.field.name: one_week_ago.strftime('%Y-%m-%d'),
							'%s__lte' % f.name: today_str}),
			(_('This month'), {'%s__year' % self.field.name: str(today.year),
							'%s__month' % f.name: str(today.month)}),
			(_('This year'), {'%s__year' % self.field.name: str(today.year)})
		)

	def title(self):
		return self.field.verbose_name

	def choices(self, cl):
		for title, param_dict in self.links:
			yield {'selected': self.date_params == param_dict,
				'query_string': cl.get_query_string(param_dict, [self.field_generic]),
				'display': title}

FilterSpec.register(lambda f: isinstance(f, models.DateField), DateFieldFilterSpec)

class BooleanFieldFilterSpec(FieldFilterSpec):
	def __init__(self, f, request, params, model, model_admin):
		super(BooleanFieldFilterSpec, self).__init__(f, request, params, model, model_admin)
		self.lookup_kwarg = '%s__exact' % f.name
		self.lookup_kwarg2 = '%s__isnull' % f.name
		self.lookup_val = request.GET.get(self.lookup_kwarg, None)
		self.lookup_val2 = request.GET.get(self.lookup_kwarg2, None)

	def title(self):
		return self.field.verbose_name

	def choices(self, cl):
		for k, v in ((_('All'), None), (_('Yes'), '1'), (_('No'), '0')):
			yield {'selected': self.lookup_val == v and not self.lookup_val2,
				'query_string': cl.get_query_string({self.lookup_kwarg: v}, [self.lookup_kwarg2]),
				'display': k}
		if isinstance(self.field, models.NullBooleanField):
			yield {'selected': self.lookup_val2 == 'True',
				'query_string': cl.get_query_string({self.lookup_kwarg2: 'True'}, [self.lookup_kwarg]),
				'display': _('Unknown')}

FilterSpec.register(lambda f: isinstance(f, models.BooleanField) or isinstance(f, models.NullBooleanField), BooleanFieldFilterSpec)

# This should be registered last, because it's a last resort. For example,
# if a field is eligible to use the BooleanFieldFilterSpec, that'd be much
# more appropriate, and the AllValuesFilterSpec won't get used for it.
class AllValuesFilterSpec(FieldFilterSpec):
	def __init__(self, f, request, params, model, model_admin):
		super(AllValuesFilterSpec, self).__init__(f, request, params, model, model_admin)
		self.lookup_val = request.GET.get(f.name, None)
		self.lookup_choices = model_admin.queryset(request).distinct().order_by(f.name).values(f.name)

	def title(self):
		return self.field.verbose_name

	def choices(self, cl):
		yield {'selected': self.lookup_val is None,
			'query_string': cl.get_query_string({}, [self.field.name]),
			'display': _('All')}
		for val in self.lookup_choices:
			val = smart_unicode(val[self.field.name])
			yield {'selected': self.lookup_val == val,
				'query_string': cl.get_query_string({self.field.name: val}),
				'display': val}
FilterSpec.register(lambda f: True, AllValuesFilterSpec)
