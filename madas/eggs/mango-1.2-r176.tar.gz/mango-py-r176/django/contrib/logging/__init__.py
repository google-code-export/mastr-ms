"""The Mango contrib logging module. Just a thin wrapper for python logger"""

from django.conf import settings
import logging, logging.handlers
import os

loggers = {}

def getLogger(name):
    if name not in loggers:
        return logging.getLogger(name) #return python root based named logger
    else:
        return loggers[name]

def init_logger(name = "mango", logfile = "mango.log"):
    #print "logging::init_logger(",name,",",logfile,")"
    fh = logging.handlers.TimedRotatingFileHandler(os.path.join(settings.LOG_DIRECTORY,logfile), 'midnight')
    fh.setFormatter(settings.LOGGING_FORMATTER)
    
    logger = logging.getLogger(name)
    logger.setLevel(settings.LOGGING_LEVEL)
    logger.addHandler(fh)

    return logger

def init():
    """Initialise the logger from the settings file..."""
    
    # TODO: improve this
    for logname in settings.LOGS:
        loggers[logname] = init_logger(logname, "%s.log"%logname)
    
init()



#logInitDone=False
#if not logInitDone:
    #logInitDone = True
    #init_logging()
