#!/usr/bin/env python

class RequestContext(dict):
    def __init__(self, request, dict=None, processors=None, current_app=None):
        self['current_app']=current_app

class Context(object):
    pass