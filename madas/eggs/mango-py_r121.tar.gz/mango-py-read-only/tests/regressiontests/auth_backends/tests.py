try:
    set
except NameError:
    from sets import Set as set     # Python 2.3 fallback

from unittest import TestCase
from django.contrib import auth
from django.http import HttpRequest
from django.contrib.auth.models import User, AnonymousUser
from django.conf import settings

class StubBackend:
    TestUser_1 = User()
    def get_user(self, id):
        if id == 1: 
            return StubBackend.TestUser_1
    
class GetUserTests(TestCase):
    def load_backend(self, backend_path):
        if backend_path == "some.backend":
            return StubBackend()

    def setUp(self):
        self.old_load_backend = auth.load_backend  
        self.old_auth_backends = settings.AUTHENTICATION_BACKENDS  

        auth.load_backend = self.load_backend 
        settings.AUTHENTICATION_BACKENDS = ("some.backend",) 

        self.request = HttpRequest()
        self.request.session = {}

    def set_up_session(self, uid, backend):
        self.request.session[auth.SESSION_KEY] = uid
        self.request.session[auth.BACKEND_SESSION_KEY] = backend

    def tearDown(self):
        auth.load_backend = self.old_load_backend
        settings.AUTHENTICATION_BACKENDS = self.old_auth_backends

    def test_user_loaded_with_backend(self):
        self.set_up_session(uid=1, backend="some.backend")
        user = auth.get_user(self.request)
        self.assertEquals(user, StubBackend.TestUser_1)

    def test_user_loaded_with_backend_invalid_uid(self):
        self.set_up_session(uid='INVALID', backend="some.backend")
        user = auth.get_user(self.request)
        self.assert_(isinstance(user,AnonymousUser))

    def test_user_loaded_with_invalid_backend(self):
        self.set_up_session(uid=1, backend="invalid.backend")
        user = auth.get_user(self.request)
        self.assert_(isinstance(user,AnonymousUser))

__test__ = {'API_TESTS': """
>>> from django.contrib.auth.models import User, Group, Permission, AnonymousUser
>>> from django.contrib.contenttypes.models import ContentType

# No Permissions assigned yet, should return False except for superuser

>>> user = User.objects.create_user('test', 'test@example.com', 'test')
>>> user.has_perm("auth.test")
False
>>> user.is_staff=True
>>> user.save()
>>> user.has_perm("auth.test")
False
>>> user.is_superuser=True
>>> user.save()
>>> user.has_perm("auth.test")
True
>>> user.is_staff = False
>>> user.is_superuser = False
>>> user.save()
>>> user.has_perm("auth.test")
False
>>> content_type=ContentType.objects.get_for_model(Group)
>>> perm = Permission.objects.create(name="test", content_type=content_type, codename="test")
>>> user.user_permissions.add(perm)
>>> user.save()

# reloading user to purge the _perm_cache

>>> user = User.objects.get(username="test")
>>> user.get_all_permissions() == set([u'auth.test'])
True
>>> user.get_group_permissions() == set([])
True
>>> user.has_module_perms("Group")
False
>>> user.has_module_perms("auth")
True
>>> perm = Permission.objects.create(name="test2", content_type=content_type, codename="test2")
>>> user.user_permissions.add(perm)
>>> user.save()
>>> perm = Permission.objects.create(name="test3", content_type=content_type, codename="test3")
>>> user.user_permissions.add(perm)
>>> user.save()
>>> user = User.objects.get(username="test")
>>> user.get_all_permissions() == set([u'auth.test2', u'auth.test', u'auth.test3'])
True
>>> user.has_perm('test')
False
>>> user.has_perm('auth.test')
True
>>> user.has_perms(['auth.test2', 'auth.test3'])
True
>>> perm = Permission.objects.create(name="test_group", content_type=content_type, codename="test_group")
>>> group = Group.objects.create(name='test_group')
>>> group.permissions.add(perm)
>>> group.save()
>>> user.groups.add(group)
>>> user = User.objects.get(username="test")
>>> exp = set([u'auth.test2', u'auth.test', u'auth.test3', u'auth.test_group'])
>>> user.get_all_permissions() == exp
True
>>> user.get_group_permissions() == set([u'auth.test_group'])
True
>>> user.has_perms(['auth.test3', 'auth.test_group'])
True

>>> user = AnonymousUser()
>>> user.has_perm('test')
False
>>> user.has_perms(['auth.test2', 'auth.test3'])
False
""",
'GetUserTests': GetUserTests}


