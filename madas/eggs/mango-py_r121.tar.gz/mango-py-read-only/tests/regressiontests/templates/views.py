# Fake views for testing url reverse lookup

def index(request):
    pass

def client(request, id):
    pass

def client_action(request, id, action):
    pass

def client2(request, tag):
    pass
